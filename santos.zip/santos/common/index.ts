export const PLUGIN_ID = 'santos';
export const PLUGIN_NAME = 'santos';
